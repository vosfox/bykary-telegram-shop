from flask_sqlalchemy import SQLAlchemy
from src.models.user import db

class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    price = db.Column(db.Float, nullable=False)
    image_url = db.Column(db.String(200))
    category = db.Column(db.String(50))
    sizes = db.Column(db.String(100))  # JSON string: ["XS", "S", "M", "L"]
    
    def to_dict(self):
        # Простая версия - используем только основное изображение
        product_images = [self.image_url] if self.image_url else ['/static/images/placeholder.svg']
        
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'price': self.price,
            'image_url': self.image_url,
            'images': product_images,  # Массив изображений
            'category': self.category,
            'sizes': self.sizes.split(',') if self.sizes else []
        }

